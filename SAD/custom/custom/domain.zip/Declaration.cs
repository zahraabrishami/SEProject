﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace domain
{
    public class Declaration
    {
        private DateTime declareDate;
        private bool granted;
        private string cExpert;
        List<Product> products;
        List<LicenseDescription> requriredLicenses;
        List<string> ownedLicensesForDecID; //licenseID

        public Declaration(string _cExpert)
        {
            declareDate = DateTime.Now;
            granted = false;
            cExpert = _cExpert;
            products = new List<Product>();
            requriredLicenses = new List<LicenseDescription>();
        }

        public void addLicense(string licenseID)
        {
            ownedLicensesForDecID.Add(licenseID);
        }

        public void addProduct(Product p)
        {
            products.Add(p);
        }

        public void findRequiredLicenses()
        {

        }


    }
 
}
