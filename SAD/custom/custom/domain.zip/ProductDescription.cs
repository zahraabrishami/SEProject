﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace domain
{
    public class ProductDescription
    {
        private string name;
        private string company;
        private string originCountry;
        private string enteranceApproach;
       //  private string productID;

        private static int counter = 1;

        public ProductDescription(string _name, string _company, string _originCountry, string _enteranceApproach)
        {
            name = _name;
            company = _company;
            originCountry = _originCountry;
            enteranceApproach = _enteranceApproach;
           // productID = counter.ToString();
            counter++;
        }
    }
}
