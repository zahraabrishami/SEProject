﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace domain
{
    public class CustomExpert : Employee
    {
        public CustomExpert(string name, string family, string staffNo, string password)
            : base(name, family, staffNo, password) { }
 
        Declaration curDeclaration = null;
        BusinessMan bMan = null;

        public void newDeclaration() {
            curDeclaration = new Declaration(this.staffNo);
        }
        public void enterBusinessmanInfo(string name, string family, string ssn)
        {
            BusinessMan bMan = DB.getBusinessman(ssn); 
            if(bMan==null){
                bMan = new BusinessMan(name, family, ssn);
            }
            bMan.addDeclaration(ref curDeclaration);     
        }
        
        public void enterProduct(string name, string company, string originCountry, string enteranceApproach, float weight, int quantity, int unitPrice)
        {
            ///////// search in db for this productDescription if not found add to DB
            ProductDescription pd = DB.getProductDescription(name, company, originCountry, enteranceApproach);
            if (pd == null)
            {
                pd = new ProductDescription(name, company, originCountry, enteranceApproach);
                //add pd to db
                DB.addProductDescription(pd);
            }
            Product p = new Product(weight, quantity, unitPrice, pd);
            curDeclaration.addProduct(p);
        }

        public void enterLicense(string licenseID)
        {
            if (bMan.hasLicense(licenseID))
            {
                LicenseDescription ld = DB.getLicenseDesciption(licenseID);
                if (ld.isValid())
                {
                    curDeclaration.addLicense(licenseID);
                    //View.shw ok;
                    return;
                }
                //view.show not valid
                return;
            }
            //view.show not yours           
        }

       public Boolean validateLicenses()
       {
          // if(//validate with rules)
                
       }    



       public void printReport()
       {
       }
    }
}
