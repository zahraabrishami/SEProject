﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace domain
{
    public class BusinessMan
    {
        private string name;
        private string family;
        private string ssn;
        private List<Declaration> ownedDeclaration;
        private List<License> ownedLicenses;

        public BusinessMan(string _name, string _family, string _ssn){
            name = _name;
            family = _family;
            ssn = _ssn;
            ownedDeclaration = new List<Declaration>();
            ownedLicenses = new List<License>();
        }

        public void addDeclaration(ref Declaration d){
            ownedDeclaration.Add(d);
        }

        public Boolean hasLicense(String licenseID)
        {
            return (ownedLicenses.Any(license => license.licenseID == licenseID));
        }

        public void addLicense(License l)
        {
            ownedLicenses.Add(l);
        }

    }
}
