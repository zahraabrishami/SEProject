﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace domain
{
    public class Rule
    {
        private float stratWeight;
        private float endWeight;
        private DateTime startDate;
        private DateTime endDate;
        private int startUnitPrice;
        private int endUnitPrice;
        private int startQuantity;
        private int endQuantity;
        private ProductDescription pDescription;

    }
}
