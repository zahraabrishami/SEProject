﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace domain
{
    public class Product
    {
        private float weight;
        private int quantity;
        private int unitPrice;
        private ProductDescription pDescription;

        public Product(float _weight, int _quantity, int _unitPrice, ProductDescription pd){
             weight = _weight;
             quantity = _quantity;
             unitPrice = _unitPrice;
             pDescription = pd;
         }
        
    }

   
}
