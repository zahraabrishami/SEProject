﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using dataAccess;

namespace domain
{
    public class LicenseDescription
    {
        private DateTime issuanceDate;
        private DateTime expireDate;
        private int goodsNumber;
        private int upperPrice;
        private ProductDescription productDescription;
        List<Rule> rules;

        public LicenseDescription(DateTime _issuanceDate, DateTime _expireDate, int _goodsNumber, int _upperPrice, ProductDescription _productDescription)
        {
            issuanceDate = _issuanceDate;
            expireDate = _expireDate;
            goodsNumber = _goodsNumber;
            upperPrice = _upperPrice;
            productDescription = _productDescription;
        }

        public Boolean isValid()
        {
            return expireDate.Date < DateTime.Now.Date;
        }
    }

}

