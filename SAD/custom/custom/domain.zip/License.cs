﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using dataAccess;

namespace domain
{
    public class License
    {
        private static int counter = 1;
        public string licenseID;
        private LicenseDescription description;

        public License(string _licenseID, LicenseDescription _description)
        {
            licenseID = _licenseID;
            description = _description;
        }

        public License(LicenseDescription _description)
        {
            string _licenseID =
            licenseID = counter.ToString();
            counter++;
            description = _description;
            DB.addLicense(this);
        }
        public string getLicenseID()
        {
            return licenseID;
        }
    }
}
