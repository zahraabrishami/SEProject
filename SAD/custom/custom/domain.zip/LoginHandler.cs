﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using dataAccess;

namespace domain
{
    public class LoginHandler
    {
        public void login(string _username, string _password)
        {
            Employee e = DB.getEmployeeByLoginInfo(_username, _password);
            if (e.Equals(null))
                view.PanelLogin.nullEmployee();
            else
            {
                switch (e.GetType().Name)
                {
                    case "CustomExpert":
                        view.PanelLogin.showCustomExpertPanel();
                        break;
                    case "OrganizationAgent":
                        view.PanelLogin.showOrganizationAgentPanel();
                        break;
                    case "CustomAdmin":
                        view.PanelLogin.showCustomAdminPanel();
                        break;
                    default:
                        break;
                }
  
            }

        }
    }
}
