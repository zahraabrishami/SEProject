﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace view
{
    public partial class PanelAdmin : Form
    {
        domain.CustomAdmin cAdmin;
        public PanelAdmin(domain.CustomAdmin _cAdmin)
        {
            cAdmin = _cAdmin;
            InitializeComponent();
        }

        private void PanelIssuanceLicense_Load(object sender, EventArgs e)
        {
            tabControlAdmin.SelectTab(tabPageAdminPanel);
            labelAgentName.Text = cAdmin.name + " " + cAdmin.family;
            startDate.Value = DateTime.Today;
            tabControlAdmin.TabPages.Remove(tabPageRuleInfo);
            tabControlAdmin.TabPages.Remove(tabPageLicenses);
            tabControlAdmin.TabPages.Remove(tabPageProductInfo);
            tabControlAdmin.TabPages.Remove(tabPageResult);
        }

        private void buttonAddRule_Click(object sender, EventArgs e)
        {
            buttonAddRule.Hide();
            logout.Hide();
            tabControlAdmin.TabPages.Add(tabPageRuleInfo);
            tabControlAdmin.SelectTab(tabPageRuleInfo);
        }

        private void buttonCancel1_Click(object sender, EventArgs e)
        {
            tabControlAdmin.TabPages.Remove(tabPageRuleInfo);
            tabControlAdmin.SelectTab(tabPageAdminPanel);
            buttonAddRule.Show();
            logout.Show();
        }

        private void buttonSubmitRuleInfo_Click(object sender, EventArgs e)
        {
            float endValue1;
            int endUnitPrice1;
            if (endValue.Value == 0)
                endValue1 = float.MaxValue;
            else
                endValue1 = (float) endValue.Value;
            if (endUnitPrice.Value == 0)
                endUnitPrice1 = int.MaxValue;
            else
                endUnitPrice1 = (int) endUnitPrice.Value;

            cAdmin.enterRuleInfo((float)startValue.Value, endValue1, startDate.Value, endDate.Value, (int)startUnitPrice.Value, endUnitPrice1);
            tabControlAdmin.TabPages.Remove(tabPageRuleInfo);
            tabControlAdmin.TabPages.Add(tabPageProductInfo);
            tabControlAdmin.SelectTab(tabPageProductInfo);
            startDate.Value = startDate.MinDate;
            endDate.Value = endDate.MaxDate;
            startUnitPrice.Value = 0;
            endUnitPrice.Value = 0;
            startValue.Value = 0;
            endValue.Value = 0;
        }

        private void buttonAddProduct_Click(object sender, EventArgs e)
        {
            if (textboxPName.Text == "")
                MessageBox.Show("لطفا نام کالا را وارد کنید\r\n");
            else
            {
                cAdmin.enterProductDescription(textboxPName.Text, textboxCompany.Text, textboxCountry.Text, comboBoxEntranceType.Text, textboxMaterial.Text);
                tabControlAdmin.TabPages.Remove(tabPageProductInfo);
                tabControlAdmin.TabPages.Add(tabPageProductInfo);
                tabControlAdmin.SelectTab(tabPageProductInfo);
                PValue.Value = 0;
                PPrice.Value = 0;
                textboxPName.Text = "";
                textboxCompany.Text = "";
                textboxCountry.Text = "";
                comboBoxEntranceType.Text = "";
                textboxMaterial.Text = "";
            }
        }

        private void buttonCancel2_Click(object sender, EventArgs e)
        {
            tabControlAdmin.TabPages.Remove(tabPageProductInfo);
            tabControlAdmin.SelectTab(tabPageAdminPanel);
            buttonAddRule.Show();
            logout.Show();
        }

        private void buttonFinalizeProducts_Click(object sender, EventArgs e)
        {
            tabControlAdmin.TabPages.Remove(tabPageProductInfo);
            tabControlAdmin.TabPages.Add(tabPageLicenses);
            tabControlAdmin.SelectTab(tabPageLicenses);
        }

        private void buttonEnd_Click(object sender, EventArgs e)
        {
            tabControlAdmin.TabPages.Remove(tabPageResult);
            tabControlAdmin.SelectTab(tabPageAdminPanel);
            buttonAddRule.Show();
            logout.Show();
        }

        static int counter = 2;

        private void newLicenseName_Click(object sender, EventArgs e)
        {
            if (licenseName1.Text == "")
                MessageBox.Show("لطفا عنوان مجوز را وارد کنید\r\n");
            else
            {
                cAdmin.enterLicenseName(licenseName1.Text);
                licenseName1.Text = "";
            }
        }

        private void finalizeRule_Click(object sender, EventArgs e)
        {
            cAdmin.submitRule();
            licenseName1.Text = "";
            tabControlAdmin.TabPages.Remove(tabPageLicenses);
            tabControlAdmin.TabPages.Add(tabPageResult);
            tabControlAdmin.SelectTab(tabPageResult);
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            tabControlAdmin.TabPages.Remove(tabPageLicenses);
            tabControlAdmin.SelectTab(tabPageAdminPanel);
            buttonAddRule.Show();
            logout.Show();
        }


        private void logout_Click_1(object sender, EventArgs e)
        {
            cAdmin = null;
            this.Hide();
            PanelLogin login = new PanelLogin();
            login.Show();
        }

    }
}
