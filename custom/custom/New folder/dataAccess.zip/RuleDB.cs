﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using domain;
using dataAccess;

namespace dataAccess
{
    public class RuleDB
    {
        public static List<domain.Rule> getRelatedRules(Product product)
        {
            List<domain.Rule> rules = new List<domain.Rule>();

            SqlConnection con = DB.connect();
            SqlDataAdapter sda = new SqlDataAdapter("select * from rules r, ruleAssociations ra where r.ruleID=ra.ruleID and ra.productDescriptionID= '" + product.pDescription.productDescriptionID + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                List<string> licenses = LicenseDB.getLicensesOfRule(dr.Field<string>("ruleID"));
                List<ProductDescription> pdl = new List<ProductDescription>();
                domain.Rule r = new domain.Rule(dr.Field<string>("ruleID"), (float)dr.Field<double>("startValue"), (float)dr.Field<double>("endValue"), dr.Field<DateTime>("startDate"), dr.Field<DateTime>("endDate"), dr.Field<int>("startUnitPrice"), dr.Field<int>("endUnitPrice"), pdl, licenses);
                rules.Add(r);
            }
            return rules;
        }

        public static void addRule(domain.Rule curRule)
        {
            SqlConnection con = DB.connect();
            SqlCommand cmd = new SqlCommand("insert into rules (ruleID, startValue, endValue, startDate, endDate,  startUnitPrice, endUnitPrice) values ('" + curRule.ruleID + "', '" + curRule.startValue + "', '" + curRule.endValue +"', '" + curRule.startDate +"', '" + curRule.endDate +"', '" + curRule.startUnitPrice+"', '" + curRule.endUnitPrice + "')", con);
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            foreach (ProductDescription pd in curRule.pDescriptions)
            {
                if (ProductDB.getProductDescription(pd.name, pd.company, pd.originCountry, pd.enteranceApproach, pd.material) == null)
                    ProductDB.addProductDescription(pd);

                foreach (string lName in curRule.licenseNames)
                {
                    cmd = new SqlCommand("insert into ruleAssociations (ruleID, licenseName, productDescriptionID) values ('" + curRule.ruleID + "', '" + lName + "', '" + pd.productDescriptionID + "')", con);
                    cmd.ExecuteNonQuery();
                }                
            }
            con.Close();
        }
    }
}
