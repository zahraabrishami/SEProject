﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using domain;

namespace dataAccess
{
    public static class DB
    {
        public static SqlConnection connect()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Howra Pishbin\Documents\Visual Studio 2012\Projects\custom\Data.mdf;Integrated Security=True;Connect Timeout=30;");
            return con;
        }       
       
    }
}
